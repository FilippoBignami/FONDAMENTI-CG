Buongiorno Professore , 
ho svolto i primi 3 punti dell'esercizio proposto ,
 purtroppo non riesco a capire cosa intende per  triangolazione nel punto 4 dell'esercizio.
Saluti FB