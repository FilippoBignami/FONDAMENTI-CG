Buongiorno Professore, sto provando a svolgere l'esercizio che ci ha richiesto. 
Purtroppo non riesco a capire come inserire i parametri seguendo il tempo, 
l'algoritmo di Casteljau credo di averlo implementato giusto ma mi manca da inserirlo riferito al tempo, 
se riuscisse a dare un'occhiata mi aiuterebbe tantissimo. la funzione in cui sto avendo problemi è bezier.
Saluti Filippo Bignami.